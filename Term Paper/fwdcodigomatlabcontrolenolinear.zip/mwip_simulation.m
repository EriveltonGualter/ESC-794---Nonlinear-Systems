close all
clear all
clc

l = 1.83; %dB = 0.87 m is the height of the body center of mass (COM) above the ankle joint axis
r = 0.203;


global u s tau_disturbance_hat tau_disturbance_real

x0= [0 ; -deg2rad(10); 0; 0];
z0 = [0;0];
current_t =0;
current_x = x0;
current_z = z0;

time =0;
states =x0;
u_vector=0;
s_vector=0;
tau_disturbance_hat_vector=[0;0];
tau_disturbance_real_vector=[0;0];
while ( current_t < 10 )
   % current_t
    [new_t_system,x] = ode45('mwip_nonlinear_system',[current_t current_t+0.0005], current_x,[], current_z);

    [new_t_obs,z] = ode45('mwip_nonlinear_observer',[current_t current_t+0.0005], current_z, [], current_x);
    
    current_x = transpose(x(end,:));
    current_z = transpose(z(end,:));
    current_t = new_t_obs(end);
    
    time = [time current_t(1,:)];
    states = [states transpose(x(end,:))];
   
    u_vector = [u_vector u];
    s_vector = [s_vector s];
    tau_disturbance_hat_vector = [tau_disturbance_hat_vector tau_disturbance_hat];
    tau_disturbance_real_vector = [tau_disturbance_real_vector tau_disturbance_real];
end

% Defaults for this blog post
width = 3;     % Width in inches
height = 3;    % Height in inches
alw = 0.75;    % AxesLineWidth
fsz = 11;      % Fontsize
lw = 1.5;      % LineWidth
msz = 8;       % MarkerSize

figure(1);
title('States Response')
subplot(2,1,1)
pos = get(gcf, 'Position');
set(gcf, 'Position', [pos(1) pos(2) width*100, height*100]); %<- Set size
set(gca, 'FontSize', fsz, 'LineWidth', alw); %<- Set properties
plot(time,states(1,:),'k-','LineWidth',lw,'MarkerSize',msz); %<- Specify plot properites
xlim([0 time(end)])
grid on
legend('x_1', 'Location', 'NorthEast');
ylabel({'wheel', 'angular position', '[rad]'});

subplot(2,1,2)
pos = get(gcf, 'Position');
set(gcf, 'Position', [pos(1) pos(2) width*100, height*100]); %<- Set size
set(gca, 'FontSize', fsz, 'LineWidth', alw); %<- Set properties
plot(time,states(2,:),'k-','LineWidth',lw,'MarkerSize',msz)
xlim([0 time(end)])
grid on
legend('x_2', 'Location', 'NorthEast');
ylabel({'pendulum' ,'angular position' ,'[rad]'});
xlabel('Time [s]')

figure(5)
subplot(2,1,1)
pos = get(gcf, 'Position');
set(gcf, 'Position', [pos(1) pos(2) width*100, height*100]); %<- Set size
set(gca, 'FontSize', fsz, 'LineWidth', alw); %<- Set properties
plot(time, states(3,:),'k-','LineWidth',lw,'MarkerSize',msz)
xlim([0 time(end)])
grid on
legend('x_3', 'Location', 'NorthEast');
ylabel({'wheel', 'angular velocity' ,'[rad/s]'});

subplot(2,1,2)
pos = get(gcf, 'Position');
set(gcf, 'Position', [pos(1) pos(2) width*100, height*100]); %<- Set size
set(gca, 'FontSize', fsz, 'LineWidth', alw); %<- Set properties
plot(time, states(4,:),'k-','LineWidth',lw,'MarkerSize',msz)
xlim([0 time(end)])
grid on
legend('x_4', 'Location', 'NorthEast');
ylabel({'pendulum' ,'angular velocity ','[rad/s]'});
xlabel('Time [s]')

% %% Animation
% subplot(5,1,5)
% O = [0, 0]; % Origin
% axis(gca, 'equal');
%  
% x = [ -states(1,:)*r; -states(1,:)*r - l*sin(states(2,:)) ];
%  
% y = [r*ones(size(states(1,:))) ; r*ones(size(states(1,:))) + l*cos(states(2,:)) ];
%  
% axis([-(l+r) (x(1,end)*1.5) 0 (l+r)])
% 
% idx = 1:length(time); 
% idxq = linspace(min(idx), max(idx), 100);    % Interpolation Vector
% 
% timei = interp1(idx, time, idxq, 'linear');       % Downsampled Vector
% xi(1,:) = interp1(idx, x(1,:), idxq, 'linear');       % Downsampled Vector
% yi(1,:) = interp1(idx, y(1,:), idxq, 'linear');       % Downsampled Vector
% xi(2,:) = interp1(idx, x(2,:), idxq, 'linear');       % Downsampled Vector
% yi(2,:) = interp1(idx, y(2,:), idxq, 'linear');       % Downsampled Vector
% 
% xlabel('x - Distance [m] ')
%  for t=1:length(xi(1,:))
% 
%      % Calculating joint coordinates for animation purpose
%     
%     pendulum = line([xi(1,t) xi(2,t)], [yi(1,t) yi(2,t)] );
%     
%     wheel = viscircles([xi(1,t) yi(1,t)],r,'LineStyle','-');
%     title(sprintf('Time: %0.2f sec', timei(t)));
%     pause(0.01)
%     delete(pendulum)
%     delete(wheel)
%  end



figure(2)

subplot(2,1,1)
pos = get(gcf, 'Position');
set(gcf, 'Position', [pos(1) pos(2) width*100, height*100]); %<- Set size
set(gca, 'FontSize', fsz, 'LineWidth', alw); %<- Set properties
plot(time, u_vector,'k-','LineWidth',lw,'MarkerSize',msz)
xlim([0 time(end)])
grid on
legend('u', 'Location', 'NorthEast');
ylabel({'wheel control','[Nm]'});

subplot(2,1,2)
pos = get(gcf, 'Position');
set(gcf, 'Position', [pos(1) pos(2) width*100, height*100]); %<- Set size
set(gca, 'FontSize', fsz, 'LineWidth', alw); %<- Set properties
plot(time, s_vector,'k-','LineWidth',lw,'MarkerSize',msz)
xlim([0 time(end)])
grid on
legend('s', 'Location', 'NorthEast');
ylabel({'sliding surface'});
xlabel('Time [s]')

figure(3)
subplot(2,1,1)
title('Disturbance Estimation')
pos = get(gcf, 'Position');
set(gcf, 'Position', [pos(1) pos(2) width*100, height*100]); %<- Set size
set(gca, 'FontSize', fsz, 'LineWidth', alw); %<- Set properties
plot(time, tau_disturbance_hat_vector(1,:),'r-',time,tau_disturbance_real_vector(1,:),'k--','LineWidth',lw,'MarkerSize',msz)
xlim([0 time(end)])
grid on
legend('\tau_d1 - estimated', '\tau_d1 - real');
ylabel({'disturbance \tau_d1','[Nm]'});

subplot(2,1,2)
pos = get(gcf, 'Position');
set(gcf, 'Position', [pos(1) pos(2) width*100, height*100]); %<- Set size
set(gca, 'FontSize', fsz, 'LineWidth', alw); %<- Set properties
plot(time, tau_disturbance_hat_vector(2,:),'r-',time,tau_disturbance_real_vector(2,:),'k--','LineWidth',lw,'MarkerSize',msz)
xlim([0 time(end)])
grid on
legend('\tau_d2 - estimated', '\tau_d2 - real');
xlabel('Time [s]')
ylabel({'disturbance \tau_d2','[Nm]'});


%% Animation
h=figure(4);

O = [0, 0]; % Origin
axis(gca, 'equal');
if(x(1,end) >l+r) 
    axis([-(l+r) (x(1,end)*2) 0 1.5*(l+r)])
else
        axis([(x(1,end)*2) (l+r) 0 1.5*(l+r)])

end
x = [ -states(1,:)*r; -states(1,:)*r - l*sin(states(2,:)) ];
 
y = [r*ones(size(states(1,:))) ; r*ones(size(states(1,:))) + l*cos(states(2,:)) ];
 

idx = 1:length(time); 
idxq = linspace(min(idx), max(idx), 100);    % Interpolation Vector

timei = interp1(idx, time, idxq, 'linear');       % Downsampled Vector
xi(1,:) = interp1(idx, x(1,:), idxq, 'linear');       % Downsampled Vector
yi(1,:) = interp1(idx, y(1,:), idxq, 'linear');       % Downsampled Vector
xi(2,:) = interp1(idx, x(2,:), idxq, 'linear');       % Downsampled Vector
yi(2,:) = interp1(idx, y(2,:), idxq, 'linear');       % Downsampled Vector

f = getframe;
[im,map] = rgb2ind(f.cdata,256,'nodither');
im(1,1,1,length(xi(1,:))) = 0;
 for t=1:length(xi(1,:))

     % Calculating joint coordinates for animation purpose
    
    pendulum = line([xi(1,t) xi(2,t)], [yi(1,t) yi(2,t)] );
    
    wheel = viscircles([xi(1,t) yi(1,t)],r,'LineStyle','-');
    title(sprintf('Time: %0.2f sec', timei(t)));
    pause(0.0001)
    
   
   drawnow;
%     frame = getframe(h);
%     im = frame2im(frame);
%     [imind,cm] = rgb2ind(im,256);
%     outfile = 'WheeledPendulum_plus.gif';
%  
%     % On the first loop, create the file. In subsequent loops, append.
%     if t==1
%         imwrite(imind,cm,outfile,'gif','DelayTime',0,'loopcount',inf);
%     else
%         imwrite(imind,cm,outfile,'gif','DelayTime',0,'writemode','append');
%     end
%     if(t ~= length(xi(1,:)))
%       delete(pendulum)
%       delete(wheel)
%      end
    
%       % Capture the plot as an image 
%       frame = getframe(h); 
%       %im = frame2im(frame); 
%       [imind,cm] = rgb2ind(frame.cdata,256,'nodither'); 
%       % Write to the GIF File 
%       if t == 1 
%           imwrite(imind,cm,filename,'gif', 'Loopcount',inf); 
%       else 
%           imwrite(imind,cm,filename,'gif','WriteMode','append'); 
%       end 
    
    
 end

%imwrite(im,map,'WheeledPendulum.gif','DelayTime',0,'LoopCount',inf) %g443800

% unlive - every quarter 
% casual leave - 2.5 
% sick leave

% figure(3)
% subplot(2,1,1)
% plot(time, states(1:2,:), 'LineWidth', 2);
% hh1(1) = line(time(1), states(1,1), 'Marker', '.', 'MarkerSize', 20, 'Color', 'b');
% hh1(2) = line(time(1), states(2,1), 'Marker', '.', 'MarkerSize', 20, 'Color', [0 .5 0]);
% xlabel('time (sec)'); ylabel('angle (deg)');
% 
% subplot(2,1,2)
% hh2 = plot([O(1), x(1,1);x(1,1), x(2,1)], [O(2), y(1,1);y(1,1), y(2,1)], ...
%       '.-', 'MarkerSize', 20, 'LineWidth', 2);
% axis equal
% axis([-2*(l+r) 2*(l+r) -2*(l+r) 2*(l+r)]);
% ht = title(sprintf('Time: %0.2f sec', time(1)));
% 
% tic;     % start timing
% for id = 1:length(time)
%    % Update XData and YData
%    set(hh1(1), 'XData', time(id)          , 'YData', states(1, id));
%    set(hh1(2), 'XData', time(id)          , 'YData', states(2, id));
%    set(hh2(1), 'XData', [0, x(1, id)]  , 'YData', [0, y(1, id)]);
%    set(hh2(2), 'XData', x(:, id)       , 'YData', y(:, id));
%    set(ht, 'String', sprintf('Time: %0.2f sec', time(id)));
% 
%    drawnow;
% end
% fprintf('Animation (Smart update): %0.2f sec\n', toc);
